/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import entities.*;
import java.util.*;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
/**
 *
 * @author THANH SI
 */
public class NhanVienModel {
    //private  static final SessionFactory sf = NewHibernateUtil.getSessionFactory();
    private static final SessionFactory sf = new Configuration().configure().buildSessionFactory();
    
    
    public static List<Employee> timKiemNV(String keyword)
    {
        Session session = sf.openSession();
        
        try{
           session.beginTransaction();
           List<Employee> list = session
                   .createQuery("from Employee where name like :name")
                   .setParameter("name", "%" + keyword + "%").list();
           return list;
          } catch (RuntimeException e) {
              return null;
              
          } finally {
              session.close();

          }
    }
}

